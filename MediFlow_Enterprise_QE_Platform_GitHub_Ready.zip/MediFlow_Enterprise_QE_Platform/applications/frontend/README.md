# React Frontend

Frontend application placeholder.
